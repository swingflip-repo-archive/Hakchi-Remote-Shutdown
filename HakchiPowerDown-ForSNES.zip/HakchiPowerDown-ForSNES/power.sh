#!/bin/sh

gameover

#rather fitting ain't it?